@include('dashboard.core.header')

@include('dashboard.core.sidebar')

@include('dashboard.core.topbar')

@yield('content')

@include('dashboard.core.footer')
