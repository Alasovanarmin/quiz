Emailinizi tesdiqlemek ucun bu linke daxil olun: <br>
<a href="{{ $link }}">Tesdiqle</a>
