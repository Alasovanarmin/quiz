<?php $__env->startSection("content"); ?>
    <h1>Suallar</h1>

    <div class="card">
        <div class="card-body">

            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <strong> <?php echo e($question->title); ?></strong>
                    <h7><?php echo e($question->description); ?></h7>
                    <div style="color: red">*
                        <?php if($question->type == 1): ?>
                            Single answer
                        <?php elseif($question->type == 2): ?>
                            Multiple answer
                        <?php elseif($question->type == 3): ?>
                            Free
                        <?php endif; ?>
                    </div>
                    <img src="" class="img-responsive" style="width: 50%;"><br>

                    <?php if(in_array($question->type, [1,2])): ?>
                        <?php $__currentLoopData = $question->answers_for_join_page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check mt-2">
                                <input class="form-check-input" type="checkbox"
                                       name="<?php echo e($answer->question_id . ($question->type == 2 ? "[]" : "")); ?>"
                                       id="" value="<?php echo e($answer->id); ?>">
                                <label class="form-check-label" for="">
                                    <?php echo e($answer->answer); ?>

                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php elseif($question->type == 3): ?>
                        <input type="text" name="<?php echo e($question->id); ?>">
                    <?php endif; ?>
                    <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <br>
                <button type="submit" class="btn btn-success btn-sm btn-block">End quiz </button>
            </form>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("site.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QuizApp\resources\views/site/quiz-join.blade.php ENDPATH**/ ?>