<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Add Quiz</h1>
        </div>

        <?php if(session()->get('success')): ?>
            <div class="alert alert-primary">
                <ul>
                    <?php echo e(session()->get('success')); ?>

                </ul>
            </div>
        <?php endif; ?>

        <?php if(session()->get('danger')): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php echo e(session()->get('danger')); ?>

                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('dashboard.quiz.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                Title
                <input type="text" name="title" class="form-control">
            </div>
            <div class="form-group">
                Description
                <textarea class="form-control" name="description" rows="6"></textarea>
            </div>
            <div class="form-group">
                Category
                <select name="category_id" id="" class="form-control">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>">
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                Status
                <select name="status" id="" class="form-control">
                    <option value="1">Aktiv</option>
                    <option value="0">Deaktiv</option>
                </select>
            </div>

            <br>

            <button type="submit" class="btn-block btn-primary btn-sm">Save</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QuizApp\resources\views/dashboard/quiz/create.blade.php ENDPATH**/ ?>