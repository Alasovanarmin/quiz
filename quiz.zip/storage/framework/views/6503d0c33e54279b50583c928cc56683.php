<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Quizzes</h1>
        </div>

        <?php if(session()->get('success')): ?>
            <div class="alert alert-primary">
                <ul>
                    <?php echo e(session()->get('success')); ?>

                </ul>
            </div>
        <?php endif; ?>

        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>Title</th>
                <th>Body</th>
                <th>Category</th>
                <th>Status</th>
                <th>Question Count</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->index + 1); ?></td>
                    <td><?php echo e($quiz->title); ?></td>
                    <td><?php echo e($quiz->description); ?></td>
                    <td><?php echo e($quiz?->category_name); ?></td>
                    <td><?php echo e($quiz->status ? "Aktiv" : "Deaktiv"); ?></td>
                    <td><?php echo e($quiz?->questions_count); ?></td>
                    <td>
                        <a href="<?php echo e(route('dashboard.quiz.questions',$quiz->id)); ?>" class="btn btn-sm btn-warning">
                            <i class="fa fa-question"></i>
                        </a>
                        <a href="<?php echo e(route('dashboard.quiz.edit', $quiz->id)); ?>" class="btn btn-sm btn-primary">
                            <i class="fa fa-pen"></i>
                        </a>
                        <a href="<?php echo e(route('dashboard.quiz.delete', $quiz->id)); ?>" class="btn btn-sm btn-danger">
                            <i class="fa fa-trash"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QuizApp\resources\views/dashboard/quiz/index.blade.php ENDPATH**/ ?>