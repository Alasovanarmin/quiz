Emailinizi tesdiqlemek ucun bu linke daxil olun: <br>
<a href="<?php echo e($link); ?>">Tesdiqle</a>
<?php /**PATH C:\xampp\htdocs\QuizApp\resources\views/mail/verify-email.blade.php ENDPATH**/ ?>