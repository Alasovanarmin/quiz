<?php $__env->startSection("content"); ?>
    <div class="row">
        <div class="col-md-8">
            <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="list-group">
                    <a href="<?php echo e(route('quiz.detail',$quiz->id)); ?>" class="list-group-item list-group-item-action flex-column align-items-start">
                        <div class="d-flex w-100 justify-content-between">
                            <h5 class="mb-1"><?php echo e($quiz->title); ?></h5>

                            <small class="text-muted"><?php echo e(date("d.m.Y", strtotime($quiz->updated_at))); ?></small>
                        </div>
                        <p class="mb-1">
                            <?php echo e($quiz->description); ?>

                        </p>
                        <small class="text-muted"><?php echo e($quiz->questions_count); ?> questions</small>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    Quizzes you join
                </div>
                <ul class="list-group list-group-flush">

                    <li class="list-group-item">
                        92 -<a href=""> QUIZ TITLE</a>
                    </li>
                    <li class="list-group-item">
                        16 -<a href=""> QUIZ TITLE</a>
                    </li>
                    <li class="list-group-item">
                        26 -<a href=""> QUIZ TITLE</a>
                    </li>

                </ul>
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("site.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QuizApp\resources\views/site/quizzes.blade.php ENDPATH**/ ?>