<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><?php echo e($quiz->title); ?> Questions</h1>
            <a href="<?php echo e(route('dashboard.question.create',$quiz_id)); ?>" class="btn btn-sm btn-info">Add</a>
        </div>

        <?php if(session()->get('success')): ?>
            <div class="alert alert-primary">
                <ul>
                    <?php echo e(session()->get('success')); ?>

                </ul>
            </div>
        <?php endif; ?>

        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>Title</th>
                <th>Description</th>
                <th>Type</th>
                <th>Level</th>
                <th>Answers</th>
                <th>Photo</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->index+1); ?></td>
                    <td><?php echo e($question->title); ?></td>
                    <td><?php echo e($question->description); ?></td>
                    <td>
                        <?php switch($question->type):
                            case (1): ?>
                                Single right answer
                                <?php break; ?>
                            <?php case (2): ?>
                                Multiple right answer
                                <?php break; ?>
                            <?php case (3): ?>
                                Free answer
                                <?php break; ?>
                        <?php endswitch; ?>
                    </td>
                    <td><?php echo e($question?->level); ?></td>
                    <td>
                        <ul>
                            <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <b><?php echo e($answer->answer); ?></b>
                                    <?php if($answer->is_true): ?>
                                        <b style="color: green">
                                             True
                                        </b>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>
                    <td> <img src="<?php echo e(asset($question->photo)); ?>" width="100"></td>
                    <td>
                        <a href="<?php echo e(route('dashboard.question.edit', $question->id)); ?>" class="btn btn-sm btn-primary">
                            <i class="fa fa-pen"></i>
                        </a>
                        <a href="<?php echo e(route('dashboard.question.delete', $question->id)); ?>" class="btn btn-sm btn-danger">
                            <i class="fa fa-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QuizApp\resources\views/dashboard/question/index.blade.php ENDPATH**/ ?>