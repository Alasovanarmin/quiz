<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">About</h1>
        </div>

        <?php if(session()->get('success')): ?>
            <div class="alert alert-primary">
                <ul>
                    <?php echo e(session()->get('success')); ?>

                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route("dashboard.about.update")); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="form-group col-md-6">
                    Email
                    <input type="text" name="email" class="form-control" value="<?php echo e($about->email); ?>">
                </div>
                <div class="form-group col-md-6">
                    Phone
                    <input type="text" name="phone" class="form-control" value="<?php echo e($about->phone); ?>">
                </div>
            </div>
            <div class="form-group">
                Summary
                <textarea class="form-control" name="summary" rows="6"><?php echo e($about->summary); ?></textarea>
            </div>
            <div class="row">
                <div class="form-group col-md-6">
                    Instagram <i class="fab fa-instagram"></i>
                    <input type="text" name="instagram" class="form-control" value="<?php echo e($about->instagram); ?>">
                </div>
                <div class="form-group col-md-6">
                    Facebook <i class="fab fa-facebook"></i>
                    <input type="text" name="facebook" class="form-control" value="<?php echo e($about->facebook); ?>">
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-6">
                    Linkedin <i class="fab fa-linkedin"></i>
                    <input type="text" name="linkedin" class="form-control" value="<?php echo e($about->linkedin); ?>">
                </div>
                <div class="form-group col-md-6">
                    Github <i class="fab fa-github"></i>
                    <input type="text" name="github" class="form-control" value="<?php echo e($about->github); ?>">
                </div>
            </div>

            <div class="form-group">
                Upload photo
                <input type="file" name="photo" class="form-control-file">
            </div>

            <img src="/<?php echo e($about->photo); ?>" width="140px">

            <br> <br>

            <button type="submit" class="btn-block btn-primary btn-sm">Update</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QuizApp\resources\views/dashboard/about.blade.php ENDPATH**/ ?>