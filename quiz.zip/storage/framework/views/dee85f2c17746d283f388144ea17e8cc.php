<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Edit Question</h1>
        </div>

        <?php if(session()->get('success')): ?>
            <div class="alert alert-primary">
                <ul>
                    <?php echo e(session()->get('success')); ?>

                </ul>
            </div>
        <?php endif; ?>

        <?php if(session()->get('danger')): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php echo e(session()->get('danger')); ?>

                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('dashboard.question.update',$question->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                Title
                <input type="text" name="title" class="form-control" value="<?php echo e($question->title); ?>">
            </div>
            <div class="form-group">
                Description
                <textarea class="form-control" name="description" rows="6"><?php echo e($question->description); ?></textarea>
            </div>
            <div class="form-group">
                Question type
                <select name="type" class="form-control">
                    <option value="1" <?php if($question->type == 1): ?> selected <?php endif; ?> >Single right answer</option>
                    <option value="2" <?php if($question->type == 2): ?> selected <?php endif; ?>>Multiple right answer</option>
                    <option value="3" <?php if($question->type == 3): ?> selected <?php endif; ?>>Free answer</option>
                </select>
            </div>

            <div class="form-group">
                Level
                <select name="level" id="" class="form-control">
                    <?php for($i = 1; $i <= 5; $i++): ?>
                        <option value="<?php echo e($i); ?>" <?php if($question->level == $i): ?> selected <?php endif; ?>><?php echo e($i); ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <div class="answers">
                    <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col-sm-6">
                            <input type="text" value="<?php echo e($answer->answer); ?>" class="form-control" name="answers[]" placeholder="Answer">
                        </div>
                        <div class="col-sm-1">
                            <button type="button"
                                    class="<?php if($loop->index == 0): ?> add-answer-input btn btn-success <?php else: ?> remove-answer-input btn btn-primary <?php endif; ?>">
                                <?php if($loop->index == 0): ?>
                                +
                                <?php else: ?>
                                -
                                <?php endif; ?>
                            </button>
                        </div>
                        <div class="col-sm-1">
                            <select class="form-control" name="is_true[]">
                                <option value="0" <?php if($answer->is_true == 0): ?> selected <?php endif; ?>>False</option>
                                <option value="1" <?php if($answer->is_true == 1): ?> selected <?php endif; ?> >True</option>
                            </select>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <br>
            <div class="form-group">
                Upload photo
                <input type="file" name="photo" class="form-control-file">
            </div>
            <br>
            <img src="/<?php echo e($question->photo); ?>" alt="" width="140px">
            <br>
            <br>
            <button type="submit" class="btn-block btn-primary btn-sm">Save</button>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('.add-answer-input').on('click',() => {
            $('.answers').append(`
                <div class="row">
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="answers[]" placeholder="Answer">
                    </div>
                    <div class="col-sm-1">
                        <div class="remove-answer-input btn btn-primary">-</div>
                    </div>
                    <div class="col-sm-1">
                        <select class="form-control" name="is_true[]">
                            <option value="0">False</option>
                            <option value="1">True</option>
                        </select>
                    </div>
                </div>
            `)
        })

        $(document).on('click','.remove-answer-input',(e) => {
            $(e.target).parent().parent().remove()
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\QuizApp\resources\views/dashboard/question/edit.blade.php ENDPATH**/ ?>